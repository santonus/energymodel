import numpy as np
import pickle
import lime
import lime.lime_tabular
import sys

username = str(sys.argv[1])
#write code to import data
file = open('C:/Users/' + username + '/.eclipse/gppt/programFeatures', 'r')
lines = file.readlines()
kepler_data = []
for i in range(0,len(lines)):
	feat,value = lines[i].split(':')
	value = float(value)
	kepler_data.append(value)

#print("Features extracted: %s" %(kepler_data))

#load the machine learning model
#make sure the machine learning model file is in the same
#dir as the script
rf_model = pickle.load(open("C:/Users/" + username + "/.eclipse/gppt/rf_finalized_model.sav", 'rb'))

y = rf_model.predict(np.array(kepler_data).reshape(1,-1))

file2= open("C:/Users/" + username + "/.eclipse/gppt/powerResult","w+")
print("Predicted Power Consumed = %s Watts" %(y))
file2.write("Predicted Power Consumed = ")
file2.write(str(y)) 

#import the power features required for lime
X_scale = []
with open('C:/Users/' + username + '/.eclipse/gppt/power_feats.pkl', 'rb') as f:
  X_scale = pickle.load(f)

#print("Dumping X_scale:")
#print(X_scale)
X_scale = np.array(X_scale)
#maintain a list of power features
feat = ['shar_inst_sim', 'comp_inst_kernel', 'shar_inst_kernel',
       'occupancy', 'block_size', 'misc_inst_sim', 'misc_inst_kernel',
       'glob_inst_kernel', 'glob_inst_sim', 'compute_capability',
       'inst_issue_cycles']

explainer = \
  lime.lime_tabular.LimeTabularExplainer(X_scale, feature_names=feat, 
  	                                     class_names=['Power'],verbose=True,
  	                                     mode='regression')

exp = explainer.explain_instance(np.array(kepler_data), rf_model.predict, num_features=10)

#show as a plot
exp.as_pyplot_figure().savefig('C:/Users/' + username + '/.eclipse/gppt/Lime_result_fig.png',bbox_inches='tight')
