package edu.bitsgoa.gppt.handlers;

import java.awt.Window;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner; // Import the Scanner class to read text files
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;

import edu.bitsgoa.gppt.startup.Startup;
import edu.bitsgoa.gppt.utilities.BetterRunProcess;
import edu.bitsgoa.gppt.views.ConsoleView;
import edu.bitsgoa.gppt.views.DisplayCustomConsole;

import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.dialogs.MessageDialog;

public class GPPTHandler extends AbstractHandler {

	
	public static boolean return_val=false;
	public static String arg1=null;		//path to the first .c file
	public static String arg2=null;		//path to the second .c file
	private static String file1=null;	//name of the first file
	private static String file2=null;	//name of the second file
	public static String result;
	public static int arch;
	public static String  benchmark; 
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
		DisplayCustomConsole.display("<<<<< Performing Energy Prediction: >>>>> ");
		try {
			Runtime rt = Runtime.getRuntime();
			arch=0;   //Default Architecture - Tesla K20
			InputDialog dlg = new InputDialog(
				    HandlerUtil.getActiveShellChecked(event), "GPU Architecture details: ",
				    "Architecture: (0-K20, 1-K4200, 2- M60, 3- V100):", "0", null);
				  if (dlg.open() == Window.ABORT) {
				   // User clicked OK; run perl
				   String input = dlg.getValue();
				  if (input=="0") arch=0;
				  else if (input=="1") arch=1;
				  else if (input=="2") arch=2;
				  else if (input=="3") arch=3;
				  }
				  InputDialog dlg2 = new InputDialog(
						    HandlerUtil.getActiveShellChecked(event), "CUDA kernel details: ",
						    "Please enter benchmark name (Note: Folder and PTX file should have the same name): ", "matmul", null);
						  if (dlg2.open() == Window.ABORT) {
						   // User clicked OK; run perl
						   String input2 = dlg.getValue();
						  benchmark=input2;
				   // TODO:do something with value
				  }
			
//			Scanner in = new Scanner(System.in);
//			System.out.println("Architecture: (0-K20, 1-K4200, 2- M60, 3- V100): ");
//			arch=in.nextInt();
//			Scanner benchin = new Scanner(System.in);
//			System.out.println("Please enter benchmark name (Note: Folder and PTX file should have the same name): ");
//			benchmark=benchin.nextLine();
			DisplayCustomConsole.display("\n** Reading PTX code **");
			Process process = rt.exec("java -jar C:\\Users\\garga\\eclipse-workspace\\edu.bitsgoa.gppt\\lib\\gppt_executable.jar "+arch+" "+benchmark);
		//	Process process2 = rt.exec("javac  C:\\Users\\garga\\eclipse-workspace\\edu.bitsgoa.gppt\\lib\\gppt_executable.jar 0 matmul");
			//Process process = Runtime.getRuntime().exec("java -jar C:\\Users\\garga\\eclipse-workspace\\edu.bitsgoa.gppt\\lib\\gppt_executable.jar 0 matmul");
			Process process2 = rt.exec("java -jar C:\\Users\\garga\\eclipse-workspace\\edu.bitsgoa.gppt\\lib\\exectime.jar "+arch+" "+benchmark);
			DisplayCustomConsole.display("\n **  Analyzing and extracting features  **");
			InputStream stderr = process.getErrorStream();
			InputStreamReader isr = new InputStreamReader(stderr);
			BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
	         String line = null;  
	           while ((line = br.readLine()) != null) {  
	              //  System.out.println(line);  
	            }  
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		File feature = new File("C:\\Users\\garga\\.eclipse\\gppt\\programFeatures");
	    Scanner myFeatureReader = null;
		try {
			myFeatureReader = new Scanner(feature);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     	while (myFeatureReader.hasNextLine())
	      {
	    	  result = myFeatureReader.nextLine();
	        System.out.println(result);
	        DisplayCustomConsole.display(result);
	      }
		DisplayCustomConsole.display("\n ** Machine learning model received feature inputs **");
	    
	    
		
		
		  File myObj = new File("C:\\Users\\garga\\.eclipse\\gppt\\powerResult");
	      Scanner myReader = null;
		try {
			myReader = new Scanner(myObj);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     	while (myReader.hasNextLine())
	      {
	    	  result = myReader.nextLine();
	       // System.out.println(result);
	      }
	    DisplayCustomConsole.display("\n** Model based prediction is complete ** ");
	    DisplayCustomConsole.display("\n"+result+ " Watts");
	    String power=result;
	    File myObj2 = new File("C:\\Users\\garga\\.eclipse\\gppt\\exresult");
	    Scanner myReader2 = null;
		try {
			myReader2 = new Scanner(myObj2);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     	while (myReader2.hasNextLine())
	      {
	    	  result = myReader2.nextLine();
	       // System.out.println(result);
	      }
	    DisplayCustomConsole.display("\n Predicted Execution Time: "+result+"us");
	    
	    DisplayCustomConsole.display("\n Predicted Energy Consumed: "+power+"*"+result+"uJ");
		DisplayCustomConsole.display("\n The feature importance using LIME figure is created in C:\\Users\\"+System.getProperty("user.name")+"\\.eclipse\\gppt\\Lime_result_fig.png");
		
		MessageDialog.openInformation(
				window.getShell(),
				"Energy Prediction Result",
				"The feature importance using LIME figure is created in C:\\Users\\"+System.getProperty("user.name")+"\\.eclipse\\gppt\\Lime_result_fig.png");
		return null;
	        
		
	//	MessageDialog.openInformation(
	//			window.getShell(),
	//			"HelloWold",
	//			"Hello, Eclipse world");
		
	}
	public static void printResult(String path){
		String fullPath=path+"GPPT_Result.txt";
		ConsoleView.text.append("******************** Results Of Energy Prediction ********************"+"\n");
		try (BufferedReader br = new BufferedReader(new FileReader(fullPath))) {
			String line;
			while ((line = br.readLine()) != null) {
				DisplayCustomConsole.display(line);
			}

		} catch(FileNotFoundException e){
			return;
		} catch (IOException e) {
			e.printStackTrace();
		} 

	}
}
